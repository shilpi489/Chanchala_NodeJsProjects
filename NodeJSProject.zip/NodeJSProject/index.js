const mongoose = require('mongoose');
const express = require("express");
const app=express();

const fs = require('fs');
const jwt = require('jsonwebtoken');

const privateKEY  = fs.readFileSync('./private.key', 'utf8');
const publicKEY  = fs.readFileSync('./public.key', 'utf8');

const bcrypt=require("bcryptjs")
app.use(express.urlencoded({ extended: true }))
app.use(express.json())

const saltRounds = 10;

mongoose.connect("mongodb://localhost:27017/demoDB",
{ useNewUrlParser: true,useUnifiedTopology: true })
.then(()=>console.log("Connection Successfully"))
.catch((err)=>console.log(err));

const db=mongoose.connection;

const UserListSchema=new mongoose.Schema({
    user_name:{
        type:String,
        //unique: true
    },
    first_name:String,
    last_name:String,
    password:String,
    phoneNo:String,
    token:String,
    state:String,
    email:{
        type:String,
        
    },
    createDate:{
        type:Date,
        default:Date.now
    }
});

const UserModel=new mongoose.model("UserModel",UserListSchema)


var verifyOptions = {
    issuer:  'Mysoft corp',
    subject:  'some@user.com',
    audience:  'http://mysoftcorp.in',
    algorithm:  "RS256"  
};


app.post("/SignUp", (req, res) => {

    db.collection("User").findOne({  $or: [ { user_name:  req.body.user_name }, { email: req.body.email } ] }
        ,(err,result)=>{
        if(result){
            if(result.user_name==req.body.user_name){
                return res.send("User already exist."); 
            }
            else if(result.email==req.body.email){
                return res.send("Email already exist."); 
            }
        }
        else{
            const password=bcrypt.hashSync(req.body.password, saltRounds);
            const user=new UserModel();
    
            user.user_name=req.body.user_name,
            user.first_name=req.body.first_name,
            user.last_name=req.body.last_name,
            user.password=password,
            user.phoneNo=req.body.phoneNo,
            user.state=req.body.state,
            user.email=req.body.email
        
            db.collection("User").insertOne(user,(err)=>{
                if(err) {
                    res.send(err);
                }
                else{
                    res.send("User created successfully.");
                }
            })
        }
        if(err){
            return res.send(err); 
        }
    })
    
        
    
});

app.post("/Login", async (req, res) => {

    const UserData=await db.collection("User").findOne({  $or: [ { user_name:  req.body.user_name },{ email: req.body.email } ] });
    if(!UserData) {
        return res.send("The username does not exist");
    }
    else if(!bcrypt.compareSync(req.body.password, UserData.password)){

        return res.send("User or password incorrect..!!");
    }
    else {
        const payload=UserData;

        

           var token = jwt.sign(payload, privateKEY, verifyOptions);
           await db.collection("User").updateOne({user_name:  UserData.user_name},
            { $set: { Token: token } })

        return res.send("Login success..  Token "+token);
    }
    
    
});

app.get("/GetUserList", async (req, res) => {
    try{
        const token=req.headers.authorization;
        //console.log(token);
        const IsVerified=jwt.verify(token, publicKEY, verifyOptions);
        console.log(IsVerified);
        if(IsVerified){

            const UserList=await db.collection("User")
            .find({ _id: { $nin:[IsVerified._id] } }).toArray();
            return res.send(UserList);
            console.log(IsVerified);
        }
        else{
            return res.send("Not verified..!!");
            console.log("Not verified..!!");
        }
    }
    catch(err){
        return res.send(err);
    }
    
    
});

app.put("/Add_Address", async (req, res) => {
    try{
        const token=req.headers.authorization;
        //console.log(token);
        const IsVerified=jwt.verify(token, publicKEY, verifyOptions);
        console.log(req.body.Address);
        if(IsVerified){

            const isAddressExist=await db.collection("User")
            .findOne({ user_name: IsVerified.user_name});

             console.log(isAddressExist.Address);
             if(!isAddressExist.Address){
            
                await db.collection("User").updateOne({user_name:  IsVerified.user_name},
                    { $push: { Address: req.body.Address } })

                const userList=await db.collection("User")
                .findOne({ user_name: IsVerified.user_name });

                    return res.send(userList);
            }
            else{
                await db.collection("User").updateOne({user_name:  IsVerified.user_name},
                    { $set: { Address: [req.body.Address] } })

                const userList=await db.collection("User")
                .findOne({ user_name: IsVerified.user_name });

                    return res.send(userList);
            }
        }
    }
    catch(err){
        return res.send(err);
    }
    
    
});

app.get("/GetUserProfile", async (req, res) => {
    try{
        const token=req.headers.authorization;
        //console.log(token);
        const IsVerified=jwt.verify(token, publicKEY, verifyOptions);
        if(IsVerified){
            
            const ProfileDetail=await db.collection("User")
                .findOne({ user_name: IsVerified.user_name });

                    return res.send(ProfileDetail);
            
        }
    }
    catch(err){
        return res.send(err);
    }
    
    
});




var server = app.listen(8082, function () {
    var host = server.address().address
    var port = server.address().port
    console.log("Example app listening at http://%s:%s", host, port)
 })
